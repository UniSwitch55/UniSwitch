import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function createDemoProduct() {
  try {
    // Crear usuario de demostración
    const { data: { user }, error: userError } = await supabase.auth.signUp({
      email: 'demo@uniswitch.com',
      password: 'demo123456'
    });

    if (userError) throw userError;

    // Crear perfil para el usuario
    const { error: profileError } = await supabase
      .from('profiles')
      .insert({
        id: user.id,
        username: 'demo_user',
        full_name: 'Usuario Demo',
        university: 'upm'
      });

    if (profileError) throw profileError;

    // Crear producto de demostración
    const { error: productError } = await supabase
      .from('products')
      .insert({
        seller_id: user.id,
        title: 'MacBook Pro 2021',
        description: 'MacBook Pro en excelente estado. Chip M1, 16GB RAM, 512GB SSD. Incluye cargador original y funda protectora.',
        price: 999.99,
        condition: 'como_nuevo',
        category: 'electronica',
        image_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8',
        status: 'available'
      });

    if (productError) throw productError;

    console.log('Producto de demostración creado exitosamente');
  } catch (error) {
    console.error('Error creando producto de demostración:', error);
  }
}

createDemoProduct();