import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  },
  global: {
    headers: { 'x-application-name': 'uniswitch' }
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// Helper function to validate UUID
export const isValidUUID = (uuid: string): boolean => {
  if (!uuid) return false;
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
};

// Helper function to create a message subscription
export const createMessageSubscription = (userId1: string, userId2: string, callback: () => void) => {
  if (!isValidUUID(userId1) || !isValidUUID(userId2)) {
    console.error('Invalid user IDs for message subscription');
    return null;
  }

  const [sortedId1, sortedId2] = [userId1, userId2].sort();
  const channelId = `messages-${sortedId1}-${sortedId2}`;

  return supabase
    .channel(channelId)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'messages',
        filter: `or(and(sender_id.eq.${sortedId1},receiver_id.eq.${sortedId2}),and(sender_id.eq.${sortedId2},receiver_id.eq.${sortedId1}))`
      },
      callback
    )
    .subscribe();
};

// Helper function to safely construct SQL filters for UUIDs
export const createUserFilter = (userId: string) => {
  if (!isValidUUID(userId)) return null;
  return `sender_id.eq.${userId},receiver_id.eq.${userId}`;
};

// Helper function to safely construct conversation filters
export const createConversationFilter = (userId1: string, userId2: string) => {
  if (!isValidUUID(userId1) || !isValidUUID(userId2)) return null;
  return `and(sender_id.eq.${userId1},receiver_id.eq.${userId2}),and(sender_id.eq.${userId2},receiver_id.eq.${userId1})`;
};