import React, { useState, useRef } from 'react';
import { Briefcase, Upload, X } from 'lucide-react';

export default function Careers() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    area: '',
    message: ''
  });
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setCvFile(file);
    } else {
      alert('Por favor, sube un archivo PDF');
    }
  };

  const removeFile = () => {
    setCvFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the data to your backend
    // For now, we'll just show the success message
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="text-green-600 mb-4">
            <svg
              className="h-16 w-16 mx-auto"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            ¡Gracias por tu solicitud!
          </h2>
          <p className="text-gray-600">
            Hemos recibido tu información y revisaremos tu perfil. Si hay una coincidencia con nuestras necesidades actuales, nos pondremos en contacto contigo pronto.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <div className="inline-block p-3 bg-primary-100 rounded-full mb-4">
          <Briefcase className="h-8 w-8 text-primary-700" />
        </div>
        <h1 className="text-3xl font-bold mb-4">Trabaja con Nosotros</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          ¿Te gustaría ser parte de nuestro equipo? En UniSwitch estamos buscando estudiantes universitarios con ganas de aprender, crecer y contribuir a nuestra misión. Si estás interesado en unirte a nosotros, llena el formulario a continuación y adjunta tu CV. ¡Esperamos conocerte!
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nombre */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre completo <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="Tu nombre"
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Correo electrónico <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="tu@email.com"
            />
          </div>

          {/* Área de interés */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Área de interés <span className="text-red-500">*</span>
            </label>
            <select
              required
              value={formData.area}
              onChange={(e) => setFormData({ ...formData, area: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
            >
              <option value="">Selecciona un área</option>
              <option value="desarrollo">Desarrollo de Software</option>
              <option value="diseño">Diseño UX/UI</option>
              <option value="marketing">Marketing Digital</option>
              <option value="soporte">Atención al Cliente</option>
              <option value="operaciones">Operaciones</option>
              <option value="otro">Otro</option>
            </select>
          </div>

          {/* CV Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Currículum Vitae (PDF) <span className="text-red-500">*</span>
            </label>
            {cvFile ? (
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Upload className="h-5 w-5 text-gray-500 mr-2" />
                  <span className="text-sm text-gray-600">{cvFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={removeFile}
                  className="p-1 hover:bg-gray-200 rounded-full"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-primary-500"
              >
                <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-500">
                  Haz clic para subir tu CV o arrastra y suelta aquí
                </p>
                <p className="text-xs text-gray-400 mt-1">Solo archivos PDF</p>
              </div>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf"
              required
              className="hidden"
            />
          </div>

          {/* Mensaje */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mensaje <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              rows={4}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="Cuéntanos por qué te gustaría unirte a nuestro equipo..."
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-primary-700 text-white rounded-lg hover:bg-primary-800 transition-colors"
          >
            Enviar solicitud
          </button>
        </form>
      </div>
    </div>
  );
}