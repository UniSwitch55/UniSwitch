import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase, isValidUUID, createMessageSubscription } from '../lib/supabase';
import { format } from 'date-fns';
import { Send, User, Image as ImageIcon, X, MessageCircle } from 'lucide-react';

type Message = {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
  image_url?: string;
  product: {
    id: string;
    title: string;
    image_url: string;
    price: number;
  };
  sender: {
    username: string;
    avatar_url: string;
  };
};

type Conversation = {
  otherUser: {
    id: string;
    username: string;
    avatar_url: string;
  };
  lastMessage: Message;
  unreadCount: number;
  product?: {
    id: string;
    title: string;
    image_url: string;
    price: number;
  };
};

export default function Messages() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sellerId = searchParams.get('seller');
  const productId = searchParams.get('product');

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }
      setCurrentUser(user);
      fetchConversations();

      if (sellerId && productId) {
        setSelectedConversation(sellerId);
        fetchMessages(sellerId);
      }
    } catch (error) {
      console.error('Error checking auth:', error);
      navigate('/auth');
    }
  };

  const fetchConversations = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: messages, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:profiles!messages_sender_id_fkey(username, avatar_url),
          product:products(*)
        `)
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Group messages by conversation
      const conversationsMap = new Map<string, Conversation>();
      messages?.forEach(message => {
        const otherUserId = message.sender_id === user.id ? message.receiver_id : message.sender_id;
        const isUnread = !message.read_at && message.receiver_id === user.id;

        if (!conversationsMap.has(otherUserId)) {
          conversationsMap.set(otherUserId, {
            otherUser: {
              id: otherUserId,
              username: message.sender_id === user.id ? message.receiver?.username : message.sender.username,
              avatar_url: message.sender_id === user.id ? message.receiver?.avatar_url : message.sender.avatar_url
            },
            lastMessage: message,
            unreadCount: isUnread ? 1 : 0,
            product: message.product
          });
        } else {
          const existing = conversationsMap.get(otherUserId)!;
          if (isUnread) {
            existing.unreadCount++;
          }
        }
      });

      setConversations(Array.from(conversationsMap.values()));
    } catch (error) {
      console.error('Error fetching conversations:', error);
    }
  };

  const fetchMessages = async (otherUserId: string) => {
    try {
      if (!currentUser) return;

      const { data: messages, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:profiles!messages_sender_id_fkey(username, avatar_url),
          product:products(*)
        `)
        .or(`and(sender_id.eq.${currentUser.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${currentUser.id})`)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(messages || []);
      scrollToBottom();

      // Mark messages as read
      const unreadMessages = messages?.filter(
        msg => !msg.read_at && msg.receiver_id === currentUser.id
      );

      if (unreadMessages?.length) {
        await supabase
          .from('messages')
          .update({ read_at: new Date().toISOString() })
          .in('id', unreadMessages.map(msg => msg.id));
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleSendMessage = async () => {
    try {
      if (!currentUser || !selectedConversation || (!newMessage.trim() && !imageFile)) return;

      let image_url = null;
      if (imageFile) {
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${currentUser.id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('messages')
          .upload(filePath, imageFile);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('messages')
          .getPublicUrl(filePath);

        image_url = publicUrl;
      }

      const { error } = await supabase
        .from('messages')
        .insert({
          sender_id: currentUser.id,
          receiver_id: selectedConversation,
          content: newMessage.trim(),
          image_url,
          product_id: productId || null
        });

      if (error) throw error;

      setNewMessage('');
      setImageFile(null);
      setImagePreview(null);
      fetchMessages(selectedConversation);
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (selectedConversation && currentUser) {
      const subscription = createMessageSubscription(
        currentUser.id,
        selectedConversation,
        () => fetchMessages(selectedConversation)
      );

      return () => {
        subscription?.unsubscribe();
      };
    }
  }, [selectedConversation, currentUser]);

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-700"></div>
    </div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="grid grid-cols-12 min-h-[600px]">
          {/* Conversations List */}
          <div className="col-span-4 border-r">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold">Mensajes</h2>
            </div>
            <div className="divide-y overflow-y-auto max-h-[calc(600px-4rem)]">
              {conversations.length === 0 ? (
                <div className="p-4 text-center text-gray-500">
                  <MessageCircle className="h-8 w-8 mx-auto mb-2" />
                  <p>No tienes conversaciones</p>
                </div>
              ) : (
                conversations.map((conversation) => (
                  <button
                    key={conversation.otherUser.id}
                    onClick={() => {
                      setSelectedConversation(conversation.otherUser.id);
                      fetchMessages(conversation.otherUser.id);
                    }}
                    className={`w-full p-4 text-left hover:bg-gray-50 ${
                      selectedConversation === conversation.otherUser.id ? 'bg-gray-50' : ''
                    }`}
                  >
                    <div className="flex items-center">
                      <img
                        src={conversation.otherUser.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'}
                        alt={conversation.otherUser.username}
                        className="w-10 h-10 rounded-full"
                      />
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">
                            {conversation.otherUser.username}
                          </span>
                          {conversation.unreadCount > 0 && (
                            <span className="bg-primary-700 text-white text-xs px-2 py-1 rounded-full">
                              {conversation.unreadCount}
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-500 truncate">
                          {conversation.lastMessage.content || 'Imagen'}
                        </p>
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className="col-span-8 flex flex-col">
            {selectedConversation ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b">
                  <div className="flex items-center">
                    <img
                      src={conversations.find(c => c.otherUser.id === selectedConversation)?.otherUser.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'}
                      alt="User avatar"
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="ml-3">
                      <h3 className="font-medium">
                        {conversations.find(c => c.otherUser.id === selectedConversation)?.otherUser.username}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${
                        message.sender_id === currentUser?.id ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      <div
                        className={`max-w-[70%] ${
                          message.sender_id === currentUser?.id
                            ? 'bg-primary-700 text-white rounded-l-lg rounded-tr-lg'
                            : 'bg-gray-100 text-gray-900 rounded-r-lg rounded-tl-lg'
                        }`}
                      >
                        {message.image_url && (
                          <img
                            src={message.image_url}
                            alt="Message attachment"
                            className="rounded-t-lg max-h-60 w-full object-cover"
                          />
                        )}
                        {message.content && (
                          <div className="p-3">
                            <p>{message.content}</p>
                            <span className="text-xs opacity-75 mt-1 block">
                              {format(new Date(message.created_at), 'HH:mm')}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <div className="p-4 border-t">
                  <div className="flex items-end space-x-4">
                    <div className="flex-1">
                      {imagePreview && (
                        <div className="relative inline-block mb-2">
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="h-20 w-20 object-cover rounded-lg"
                          />
                          <button
                            onClick={removeImage}
                            className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow-md"
                          >
                            <X className="h-4 w-4 text-gray-500" />
                          </button>
                        </div>
                      )}
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Escribe un mensaje..."
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2 text-gray-500 hover:text-primary-700"
                      >
                        <ImageIcon className="h-6 w-6" />
                      </button>
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleImageUpload}
                        accept="image/*"
                        className="hidden"
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim() && !imageFile}
                        className="p-2 text-white bg-primary-700 rounded-lg hover:bg-primary-800 disabled:opacity-50"
                      >
                        <Send className="h-6 w-6" />
                      </button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <MessageCircle className="h-12 w-12 mb-4" />
                <p>Selecciona una conversación para empezar a chatear</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}