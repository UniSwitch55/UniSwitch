import React from 'react';
import { Link } from 'react-router-dom';
import { UserPlus, Upload, Search, MessageCircle, Shield, CreditCard, Lightbulb, LifeBuoy } from 'lucide-react';

export default function Guide() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      {/* Previous content remains the same until the Security section */}
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900">Guía de Uso - UniSwitch</h1>
        <p className="mt-4 text-gray-600">
          ¡Bienvenido a UniSwitch! Sigue estos pasos para empezar a comprar, vender y conectar con estudiantes de tu universidad de forma segura y rápida.
        </p>
      </div>

      <div className="space-y-8">
        {/* 1. Registro y Configuración */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <UserPlus className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">1. Registro y Configuración</h2>
          </div>
          <div className="ml-11">
            <p className="mb-2">Accede a UniSwitch: Visita nuestro sitio web/app.</p>
            <p className="mb-2">Crea tu cuenta:</p>
            <ul className="list-disc ml-6 mb-2">
              <li>Ingresa tu correo universitario.</li>
              <li>Recibirás un enlace de verificación para confirmar tu identidad como estudiante.</li>
            </ul>
            <p className="mb-2">Completa tu perfil:</p>
            <ul className="list-disc ml-6">
              <li>Agrega tu foto, nombre y detalles básicos para que otros estudiantes puedan reconocerte fácilmente.</li>
            </ul>
          </div>
        </section>

        {/* 2. Publicar un Producto */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Upload className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">2. Publicar un Producto</h2>
          </div>
          <div className="ml-11">
            <p className="mb-2">Haz clic en "Vender" en el menú principal.</p>
            <p className="mb-2">Llena los detalles del producto:</p>
            <ul className="list-disc ml-6">
              <li>Título (por ejemplo, "Libro de Economía 101").</li>
              <li>Descripción detallada.</li>
              <li>Precio (puedes marcarlo como negociable).</li>
              <li>Subir fotos claras y de calidad.</li>
              <li>Selecciona la categoría adecuada (tecnología, libros, ropa, etc.).</li>
            </ul>
            <p className="mt-2">Publica el anuncio y estará visible para otros estudiantes.</p>
          </div>
        </section>

        {/* 3. Comprar un Producto */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Search className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">3. Comprar un Producto</h2>
          </div>
          <div className="ml-11">
            <p className="mb-2">Explora los productos: Usa el buscador o filtra por categorías o universidad.</p>
            <p className="mb-2">Encuentra lo que necesitas:</p>
            <ul className="list-disc ml-6 mb-2">
              <li>Revisa la descripción y las fotos.</li>
              <li>Mira el perfil del vendedor para mayor seguridad.</li>
            </ul>
            <p className="mb-2">Contacta al vendedor: Envía un mensaje para negociar el precio o resolver dudas.</p>
            <p>Coordina la entrega: Puedes quedar en persona dentro del campus o usar servicios de envío según lo acuerden.</p>
          </div>
        </section>

        {/* 4. Seguridad y Confianza */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Shield className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">4. Seguridad y Confianza</h2>
          </div>
          <div className="ml-11">
            <ul className="list-disc ml-6">
              <li>Compra solo a estudiantes verificados: En UniSwitch, todos los usuarios tienen correos universitarios.</li>
              <li>Revisa perfiles y opiniones: Conoce la reputación del vendedor o comprador antes de concretar la transacción.</li>
              <li>Reporta cualquier problema: Si notas algo sospechoso, contáctanos en <Link to="/support" className="text-primary-700 hover:underline">infouniswitch@gmail.com</Link>.</li>
            </ul>
          </div>
        </section>

        {/* 5. Tarifas y Comisión */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <CreditCard className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">5. Tarifas y Comisión</h2>
          </div>
          <div className="ml-11">
            <ul className="list-disc ml-6">
              <li>Publicar un producto es gratis.</li>
              <li>Se aplica una pequeña comisión por transacción para mantener la plataforma operativa y segura.</li>
            </ul>
          </div>
        </section>

        {/* 6. Consejos para Maximizar tu Experiencia */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Lightbulb className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">6. Consejos para Maximizar tu Experiencia</h2>
          </div>
          <div className="ml-11">
            <ul className="list-disc ml-6">
              <li>Usa buenos títulos y fotos: Los anuncios con imágenes claras tienen más éxito.</li>
              <li>Sé claro y honesto: Describe el estado real del producto.</li>
              <li>Valora a otros estudiantes: Después de cada transacción, deja una valoración para ayudar a construir confianza.</li>
            </ul>
          </div>
        </section>

        {/* 7. Soporte y Ayuda */}
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <LifeBuoy className="h-8 w-8 text-primary-700 mr-3" />
            <h2 className="text-xl font-bold">7. Soporte y Ayuda</h2>
          </div>
          <div className="ml-11">
            <p>¿Tienes dudas o necesitas ayuda? Escríbenos a <Link to="/support" className="text-primary-700 hover:underline">infouniswitch@gmail.com</Link>.</p>
          </div>
        </section>
      </div>

      <div className="text-center mt-12">
        <p className="text-lg text-gray-600">
          ¡Gracias por ser parte de UniSwitch, el marketplace hecho por y para estudiantes! 🎓✨
        </p>
      </div>
    </div>
  );
}