import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Camera, Edit2, Star, Package, ShoppingBag, Eye, Heart, Bookmark, CreditCard, History } from 'lucide-react';
import { format } from 'date-fns';
import UniversitySelect from '../components/UniversitySelect';
import { universities } from '../lib/universities';

type Profile = {
  id: string;
  username: string;
  full_name: string;
  avatar_url: string;
  bio: string;
  university: string;
};

type Product = {
  id: string;
  title: string;
  price: number;
  image_url: string;
  status: string;
  created_at: string;
};

type SavedProduct = {
  id: string;
  product: Product;
  created_at: string;
};

type Review = {
  id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer: {
    username: string;
    avatar_url: string;
  };
};

type OrderHistory = {
  id: string;
  status: string;
  created_at: string;
  product: Product;
};

export default function Profile() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [savedProducts, setSavedProducts] = useState<SavedProduct[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('products');
  const [editForm, setEditForm] = useState({
    full_name: '',
    bio: '',
    university: ''
  });
  const [reviews, setReviews] = useState<Review[]>([]);
  const [orderHistory, setOrderHistory] = useState<OrderHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      // Fetch profile data
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;

      setProfile(profile);
      setEditForm({
        full_name: profile.full_name || '',
        bio: profile.bio || '',
        university: profile.university || ''
      });

      // Fetch user's products
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('*')
        .eq('seller_id', user.id)
        .order('created_at', { ascending: false });

      if (productsError) throw productsError;
      setProducts(products || []);

      // Fetch saved products
      const { data: savedProducts, error: savedError } = await supabase
        .from('saved_products')
        .select(`
          id,
          created_at,
          product:products (*)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (savedError) throw savedError;
      setSavedProducts(savedProducts || []);

      // Fetch reviews
      const { data: reviews, error: reviewsError } = await supabase
        .from('reviews')
        .select(`
          *,
          reviewer:profiles!reviews_reviewer_id_fkey(username, avatar_url)
        `)
        .eq('seller_id', user.id)
        .order('created_at', { ascending: false });

      if (reviewsError) throw reviewsError;
      setReviews(reviews || []);

      // Fetch order history
      const { data: orders, error: ordersError } = await supabase
        .from('orders')
        .select(`
          *,
          product:products(*)
        `)
        .or(`buyer_id.eq.${user.id},seller_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;
      setOrderHistory(orders || []);

    } catch (error) {
      console.error('Error fetching profile:', error);
      setError('Error al cargar el perfil');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: editForm.full_name,
          bio: editForm.bio,
          university: editForm.university,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) throw error;
      
      setProfile(prev => prev ? {
        ...prev,
        full_name: editForm.full_name,
        bio: editForm.bio,
        university: editForm.university
      } : null);
      
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error updating profile:', error);
      setError('Error al actualizar el perfil');
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-700"></div>
    </div>;
  }

  if (!profile) {
    return <div className="text-center py-8">
      <p className="text-red-600">Error al cargar el perfil</p>
      <button
        onClick={() => navigate('/auth')}
        className="mt-4 px-6 py-2 bg-primary-700 text-white rounded-lg hover:bg-primary-800"
      >
        Iniciar sesión
      </button>
    </div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {/* Profile Header */}
        <div className="relative h-32 bg-gradient-to-r from-primary-700 to-primary-800">
          <div className="absolute -bottom-16 left-8">
            <div className="relative">
              <img
                src={profile.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'}
                alt={profile.username}
                className="w-32 h-32 rounded-full border-4 border-white object-cover"
              />
              <label className="absolute bottom-0 right-0 bg-white rounded-full p-2 shadow-lg cursor-pointer">
                <Camera className="h-5 w-5 text-gray-600" />
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        <div className="pt-20 px-8 pb-8">
          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Nombre completo
                </label>
                <input
                  type="text"
                  value={editForm.full_name}
                  onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Biografía
                </label>
                <textarea
                  value={editForm.bio}
                  onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Universidad
                </label>
                <UniversitySelect
                  value={editForm.university}
                  onChange={(value) => setEditForm({ ...editForm, university: value })}
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleUpdateProfile}
                  className="px-4 py-2 bg-primary-700 text-white rounded-md hover:bg-primary-800"
                >
                  Guardar cambios
                </button>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">
                    {profile.full_name || profile.username}
                  </h1>
                  <p className="text-gray-500">@{profile.username}</p>
                  {profile.university && (
                    <p className="text-gray-600 mt-1">
                      {universities.find(u => u.id === profile.university)?.name}
                    </p>
                  )}
                </div>
                <div className="flex space-x-3">
                  <Link
                    to="/payment-info"
                    className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    <CreditCard className="h-4 w-4" />
                    <span>Información de pago</span>
                  </Link>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    <Edit2 className="h-4 w-4" />
                    <span>Editar perfil</span>
                  </button>
                </div>
              </div>
              {profile.bio && (
                <p className="mt-4 text-gray-600">{profile.bio}</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-8">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('products')}
              className={`${
                activeTab === 'products'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <Package className="h-5 w-5 mr-2" />
              Mis productos
            </button>
            <button
              onClick={() => setActiveTab('saved')}
              className={`${
                activeTab === 'saved'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <Bookmark className="h-5 w-5 mr-2" />
              Guardados
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`${
                activeTab === 'reviews'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <Star className="h-5 w-5 mr-2" />
              Valoraciones
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`${
                activeTab === 'history'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <History className="h-5 w-5 mr-2" />
              Historial
            </button>
          </nav>
        </div>

        <div className="mt-6">
          {activeTab === 'products' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <Link
                  key={product.id}
                  to={`/products/${product.id}`}
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="aspect-square relative">
                    <img
                      src={product.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                      alt={product.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <p className="font-bold text-xl text-primary-700">
                      €{product.price.toFixed(2)}
                    </p>
                    <h3 className="text-gray-900 font-medium line-clamp-1">
                      {product.title}
                    </h3>
                    <div className="flex justify-between items-center mt-2">
                      <span className={`px-2 py-1 rounded-full text-sm ${
                        product.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {product.status === 'available' ? 'Disponible' : 'Vendido'}
                      </span>
                      <span className="text-sm text-gray-500">
                        {format(new Date(product.created_at), 'dd/MM/yyyy')}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {activeTab === 'saved' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedProducts.map((saved) => (
                <Link
                  key={saved.id}
                  to={`/products/${saved.product.id}`}
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="aspect-square relative">
                    <img
                      src={saved.product.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                      alt={saved.product.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <p className="font-bold text-xl text-primary-700">
                      €{saved.product.price.toFixed(2)}
                    </p>
                    <h3 className="text-gray-900 font-medium line-clamp-1">
                      {saved.product.title}
                    </h3>
                    <div className="flex justify-between items-center mt-2">
                      <span className={`px-2 py-1 rounded-full text-sm ${
                        saved.product.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {saved.product.status === 'available' ? 'Disponible' : 'Vendido'}
                      </span>
                      <span className="text-sm text-gray-500">
                        {format(new Date(saved.created_at), 'dd/MM/yyyy')}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {reviews.map((review) => (
                <div key={review.id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex items-center mb-4">
                    <img
                      src={review.reviewer.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'}
                      alt={review.reviewer.username}
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="ml-4">
                      <p className="font-medium">{review.reviewer.username}</p>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <span className="ml-auto text-sm text-gray-500">
                      {format(new Date(review.created_at), 'dd/MM/yyyy')}
                    </span>
                  </div>
                  <p className="text-gray-600">{review.comment}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-6">
              {orderHistory.map((order) => (
                <div key={order.id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex items-center">
                    <img
                      src={order.product.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                      alt={order.product.title}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="ml-6 flex-1">
                      <h3 className="font-medium">{order.product.title}</h3>
                      <p className="text-gray-500">
                        Precio: €{order.product.price.toFixed(2)}
                      </p>
                      <div className="flex justify-between items-center mt-2">
                        <span className={`px-2 py-1 rounded-full text-sm ${
                          order.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {order.status === 'completed' ? 'Completado' : 'Pendiente'}
                        </span>
                        <span className="text-sm text-gray-500">
                          {format(new Date(order.created_at), 'dd/MM/yyyy')}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}