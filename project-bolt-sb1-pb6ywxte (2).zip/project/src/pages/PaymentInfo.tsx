import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { CreditCard, Phone, Mail } from 'lucide-react';

type PaymentInfo = {
  paypal_email: string | null;
  bizum_phone: string | null;
  card_last_four: string | null;
  card_brand: string | null;
};

export default function PaymentInfo() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo>({
    paypal_email: '',
    bizum_phone: '',
    card_last_four: null,
    card_brand: null
  });

  useEffect(() => {
    fetchPaymentInfo();
  }, []);

  const fetchPaymentInfo = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      const { data } = await supabase
        .from('payment_info')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (data) {
        setPaymentInfo(data);
      }
    } catch (error) {
      console.error('Error fetching payment info:', error);
      setError('Error al cargar la información de pago');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('payment_info')
        .upsert({
          user_id: user.id,
          ...paymentInfo,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      navigate('/profile');
    } catch (error: any) {
      console.error('Error updating payment info:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-700"></div>
    </div>;
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Información de Pago</h1>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 bg-white rounded-lg shadow-md p-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center">
              <Mail className="h-5 w-5 mr-2" />
              Correo de PayPal
            </div>
          </label>
          <input
            type="email"
            value={paymentInfo.paypal_email || ''}
            onChange={(e) => setPaymentInfo({ ...paymentInfo, paypal_email: e.target.value })}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
            placeholder="tu.correo@ejemplo.com"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center">
              <Phone className="h-5 w-5 mr-2" />
              Número de Bizum
            </div>
          </label>
          <input
            type="tel"
            value={paymentInfo.bizum_phone || ''}
            onChange={(e) => setPaymentInfo({ ...paymentInfo, bizum_phone: e.target.value })}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
            placeholder="+34 XXX XXX XXX"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Tarjeta de Crédito/Débito
            </div>
          </label>
          {paymentInfo.card_last_four ? (
            <div className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded-lg">
              <span>
                {paymentInfo.card_brand} **** **** **** {paymentInfo.card_last_four}
              </span>
              <button
                type="button"
                onClick={() => setPaymentInfo({ ...paymentInfo, card_last_four: null, card_brand: null })}
                className="text-red-600 hover:text-red-700"
              >
                Eliminar
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => alert('Esta es una demo. En producción, aquí se integraría un procesador de pagos.')}
              className="w-full px-3 py-2 border rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Añadir tarjeta
            </button>
          )}
        </div>

        <div className="flex gap-4 pt-4">
          <button
            type="button"
            onClick={() => navigate('/profile')}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={loading}
            className="flex-1 px-4 py-2 bg-primary-700 text-white rounded-lg hover:bg-primary-800"
          >
            {loading ? 'Guardando...' : 'Guardar cambios'}
          </button>
        </div>
      </form>
    </div>
  );
}