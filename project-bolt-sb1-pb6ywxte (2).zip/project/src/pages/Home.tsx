import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Plus, MapPin, ChevronDown, ShoppingBag, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';

type Product = {
  id: string;
  title: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
  seller: {
    username: string;
    university: string;
  }
};

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([]);
  const [recentProducts, setRecentProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const galleryImages = [
    {
      url: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644',
      title: 'Explora productos',
      description: 'Encuentra todo lo que necesitas para tus estudios',
      action: {
        text: 'Explorar productos',
        link: '/products',
        icon: <ShoppingBag className="h-5 w-5 mr-2" />
      }
    },
    {
      url: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173',
      title: 'Vende tus productos',
      description: 'Gana dinero extra vendiendo lo que ya no uses',
      action: {
        text: 'Vender',
        link: '/products/new',
        icon: <Upload className="h-5 w-5 mr-2" />
      }
    },
    {
      url: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1',
      title: 'Conecta con estudiantes',
      description: 'Compra y vende dentro de tu universidad',
      action: {
        onClick: () => navigate('/auth', { state: { isLogin: false } }),
        text: 'Unirse ahora',
        icon: <Plus className="h-5 w-5 mr-2" />
      }
    }
  ];

  const categories = [
    { id: 'libros', name: 'Libros y Material', icon: '📚' },
    { id: 'electronica', name: 'Electrónica', icon: '📱' },
    { id: 'ropa', name: 'Ropa y Accesorios', icon: '👕' },
    { id: 'muebles', name: 'Muebles', icon: '🪑' },
    { id: 'deportes', name: 'Deportes', icon: '⚽' },
    { id: 'otros', name: 'Otros', icon: '📦' },
  ];

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      // Fetch user's recent searches if logged in
      let recommendedProductIds: string[] = [];
      if (user) {
        const { data: searchHistory } = await supabase
          .from('search_history')
          .select('product_id')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(10);

        if (searchHistory) {
          recommendedProductIds = searchHistory
            .map(item => item.product_id)
            .filter(Boolean);
        }
      }

      // Fetch recommended products based on search history
      if (recommendedProductIds.length > 0) {
        const { data: recommended } = await supabase
          .from('products')
          .select(`
            *,
            seller:profiles(username, university)
          `)
          .in('id', recommendedProductIds)
          .eq('status', 'available')
          .limit(8);

        if (recommended) {
          setRecommendedProducts(recommended);
        }
      }

      // Fetch recent products
      const { data: recent } = await supabase
        .from('products')
        .select(`
          *,
          seller:profiles(username, university)
        `)
        .eq('status', 'available')
        .order('created_at', { ascending: false })
        .limit(8);

      if (recent) {
        setRecentProducts(recent);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const ProductGrid = ({ products, title }: { products: Product[], title: string }) => (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <Link
            key={product.id}
            to={`/products/${product.id}`}
            className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow overflow-hidden group"
          >
            <div className="aspect-square relative">
              <img
                src={product.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                alt={product.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-opacity" />
            </div>
            <div className="p-4">
              <p className="font-bold text-xl text-primary-700">
                €{product.price.toFixed(2)}
              </p>
              <h3 className="text-gray-900 font-medium line-clamp-1">
                {product.title}
              </h3>
              <div className="flex items-center text-sm text-gray-500 mt-2">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{product.seller.university}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Interactive Gallery */}
      <div className="relative h-[500px] overflow-hidden">
        <div className="flex h-full">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className="relative flex-1 transition-all duration-500 ease-in-out hover:flex-[1.5]"
            >
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-500"
                style={{ backgroundImage: `url(${image.url})` }}
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 transition-opacity duration-500" />
              <div className="absolute inset-0 flex flex-col justify-center px-8 text-white">
                <h2 className="text-3xl font-bold mb-4">{image.title}</h2>
                <p className="text-lg mb-6">{image.description}</p>
                {image.action.link ? (
                  <Link
                    to={image.action.link}
                    className="inline-flex items-center bg-white text-primary-700 px-6 py-3 rounded-lg hover:bg-secondary-400 hover:text-white transition-colors w-fit"
                  >
                    {image.action.icon}
                    {image.action.text}
                  </Link>
                ) : (
                  <button
                    onClick={image.action.onClick}
                    className="inline-flex items-center bg-white text-primary-700 px-6 py-3 rounded-lg hover:bg-secondary-400 hover:text-white transition-colors w-fit"
                  >
                    {image.action.icon}
                    {image.action.text}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Products Section */}
        {recommendedProducts.length > 0 && (
          <ProductGrid 
            products={recommendedProducts} 
            title="Recomendados para ti" 
          />
        )}

        {/* Recent Products */}
        <ProductGrid 
          products={recentProducts} 
          title={recommendedProducts.length > 0 ? "Productos recientes" : "Últimos productos"} 
        />

        {/* Categories */}
        <div className="mt-12">
          <h2 className="text-xl font-bold mb-4">Explora por categorías</h2>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/products?category=${category.id}`}
                className="flex flex-col items-center p-4 rounded-lg transition-all hover:bg-white hover:shadow-md bg-white/50"
              >
                <span className="text-2xl mb-2">{category.icon}</span>
                <span className="text-sm text-center font-medium">{category.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}