import React, { useState, useEffect } from 'react';
import { useLocation, useSearchParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Filter, X } from 'lucide-react';
import UniversitySelect from '../components/UniversitySelect';
import { universities } from '../lib/universities';

type Product = {
  id: string;
  title: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
  seller: {
    username: string;
    university: string;
  }
};

const categories = [
  { id: 'libros', name: 'Libros y Material', icon: '📚' },
  { id: 'electronica', name: 'Electrónica', icon: '📱' },
  { id: 'ropa', name: 'Ropa y Accesorios', icon: '👕' },
  { id: 'muebles', name: 'Muebles', icon: '🪑' },
  { id: 'deportes', name: 'Deportes', icon: '⚽' },
  { id: 'otros', name: 'Otros', icon: '📦' },
];

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const location = useLocation();

  // Filter states
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [selectedUniversity, setSelectedUniversity] = useState(searchParams.get('university') || '');
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') || '');
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') || '');
  const searchQuery = searchParams.get('search') || '';

  useEffect(() => {
    if (location.pathname !== '/products/new') {
      fetchProducts();
    }
  }, [searchParams, location.pathname]);

  const fetchProducts = async () => {
    try {
      let query = supabase
        .from('products')
        .select(`
          *,
          seller:profiles(username, university)
        `)
        .eq('status', 'available');

      if (searchQuery) {
        query = query.ilike('title', `%${searchQuery}%`);
      }

      if (selectedCategory) {
        query = query.eq('category', selectedCategory);
      }

      if (selectedUniversity) {
        query = query.eq('seller.university', selectedUniversity);
      }

      if (minPrice) {
        query = query.gte('price', parseFloat(minPrice));
      }

      if (maxPrice) {
        query = query.lte('price', parseFloat(maxPrice));
      }

      const { data, error } = await query;
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    const newParams = new URLSearchParams(searchParams);
    
    if (selectedCategory) {
      newParams.set('category', selectedCategory);
    } else {
      newParams.delete('category');
    }

    if (selectedUniversity) {
      newParams.set('university', selectedUniversity);
    } else {
      newParams.delete('university');
    }

    if (minPrice) {
      newParams.set('minPrice', minPrice);
    } else {
      newParams.delete('minPrice');
    }

    if (maxPrice) {
      newParams.set('maxPrice', maxPrice);
    } else {
      newParams.delete('maxPrice');
    }

    setSearchParams(newParams);
  };

  const clearFilters = () => {
    setSelectedCategory('');
    setSelectedUniversity('');
    setMinPrice('');
    setMaxPrice('');
    setSearchParams(searchQuery ? { search: searchQuery } : {});
  };

  const hasActiveFilters = selectedCategory || selectedUniversity || minPrice || maxPrice;

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-700"></div>
    </div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">
          {searchQuery ? `Resultados para "${searchQuery}"` : 'Todos los productos'}
        </h1>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center px-4 py-2 text-gray-600 hover:text-primary-700"
        >
          <Filter className="h-5 w-5 mr-2" />
          Filtros
        </button>
      </div>
      
      {/* Filters Section */}
      {showFilters && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Category Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Categoría
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
              >
                <option value="">Todas las categorías</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            {/* University Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Universidad
              </label>
              <UniversitySelect
                value={selectedUniversity}
                onChange={setSelectedUniversity}
              />
            </div>

            {/* Price Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Precio mínimo (€)
              </label>
              <input
                type="number"
                min="0"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Precio máximo (€)
              </label>
              <input
                type="number"
                min="0"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="1000"
              />
            </div>
          </div>

          {/* Filter Actions */}
          <div className="flex justify-end items-center mt-6 space-x-4">
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center px-4 py-2 text-gray-600 hover:text-red-600"
              >
                <X className="h-4 w-4 mr-2" />
                Limpiar filtros
              </button>
            )}
            <button
              onClick={applyFilters}
              className="px-6 py-2 bg-primary-700 text-white rounded-lg hover:bg-primary-800"
            >
              Aplicar filtros
            </button>
          </div>
        </div>
      )}

      {/* Active Filters Tags */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 mb-6">
          {selectedCategory && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-700">
              {categories.find(c => c.id === selectedCategory)?.name}
              <button
                onClick={() => {
                  setSelectedCategory('');
                  applyFilters();
                }}
                className="ml-2"
              >
                <X className="h-4 w-4" />
              </button>
            </span>
          )}
          {selectedUniversity && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-700">
              {universities.find(u => u.id === selectedUniversity)?.name}
              <button
                onClick={() => {
                  setSelectedUniversity('');
                  applyFilters();
                }}
                className="ml-2"
              >
                <X className="h-4 w-4" />
              </button>
            </span>
          )}
          {minPrice && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-700">
              Desde {minPrice}€
              <button
                onClick={() => {
                  setMinPrice('');
                  applyFilters();
                }}
                className="ml-2"
              >
                <X className="h-4 w-4" />
              </button>
            </span>
          )}
          {maxPrice && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-700">
              Hasta {maxPrice}€
              <button
                onClick={() => {
                  setMaxPrice('');
                  applyFilters();
                }}
                className="ml-2"
              >
                <X className="h-4 w-4" />
              </button>
            </span>
          )}
        </div>
      )}
      
      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.length > 0 ? (
          products.map((product) => (
            <Link 
              key={product.id} 
              to={`/products/${product.id}`}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <img
                src={product.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                alt={product.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h2 className="text-xl font-semibold mb-2">{product.title}</h2>
                <p className="text-gray-600 mb-4 line-clamp-2">{product.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-primary-700">
                    €{product.price.toFixed(2)}
                  </span>
                  <span className="text-sm text-gray-500">
                    {universities.find(u => u.id === product.seller.university)?.name}
                  </span>
                </div>
              </div>
            </Link>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <p className="text-gray-500 text-lg">No se encontraron productos</p>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="mt-4 text-primary-700 hover:text-primary-800"
              >
                Limpiar filtros
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}