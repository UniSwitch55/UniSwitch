import React from 'react';
import { Link } from 'react-router-dom';
import { 
  UserCheck, 
  Mail, 
  Star, 
  MessageSquare, 
  Shield, 
  Flag, 
  CreditCard, 
  Lightbulb, 
  MapPin,
  AlertTriangle,
  Eye,
  Lock
} from 'lucide-react';

export default function Security() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center mb-4">Seguridad en UniSwitch</h1>
      <p className="text-gray-600 text-center mb-12">
        En UniSwitch, la seguridad de nuestros usuarios es nuestra prioridad. Por eso, hemos implementado una serie de medidas para garantizar que puedas comprar, vender y conectar con otros estudiantes de manera segura y confiable.
      </p>

      <div className="space-y-12">
        {/* 1. Registro Seguro */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <UserCheck className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">1. Registro Seguro y Restricción por Correos Universitarios</h2>
              <div className="space-y-4">
                <p><strong>Acceso exclusivo para estudiantes:</strong> Solo permitimos registros con correos electrónicos asociados a universidades (por ejemplo, @universidad.edu). Esto asegura que todos los usuarios sean parte de una comunidad académica.</p>
                <p><strong>Verificación por correo:</strong> Antes de activar tu cuenta, te enviaremos un enlace de verificación a tu correo universitario para confirmar tu identidad.</p>
                <p><strong>Beneficio:</strong> Esta medida protege nuestra comunidad al garantizar que solo estudiantes activos accedan a la plataforma.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 2. Identidad Verificada */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <Mail className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">2. Identidad Verificada</h2>
              <div className="space-y-4">
                <p><strong>Perfiles reales:</strong> Todos los usuarios deben completar su perfil con información básica, como su nombre y la universidad a la que pertenecen.</p>
                <p><strong>Beneficio:</strong> Esto ayuda a generar confianza entre compradores y vendedores, fomentando un ambiente más seguro.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Valoraciones y Reseñas */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <Star className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">3. Valoraciones y Reseñas</h2>
              <div className="space-y-4">
                <p><strong>Sistema de reputación:</strong> Después de cada transacción, los usuarios pueden calificar y dejar comentarios sobre su experiencia.</p>
                <p><strong>Indicadores de confianza:</strong> Los perfiles muestran una calificación promedio y las reseñas recientes.</p>
                <p><strong>Beneficio:</strong> Este sistema permite identificar a los usuarios más confiables y promueve buenas prácticas en la comunidad.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Mensajería Interna */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <MessageSquare className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">4. Mensajería Interna y Moderación</h2>
              <div className="space-y-4">
                <p><strong>Chat seguro:</strong> Todas las comunicaciones entre compradores y vendedores se realizan dentro de UniSwitch.</p>
                <p><strong>Protección de datos:</strong> Bloqueamos mensajes que incluyan información de contacto externa, como números de teléfono o correos personales.</p>
                <p><strong>Moderación activa:</strong> Nuestro equipo supervisa las conversaciones para detectar comportamientos sospechosos o inapropiados.</p>
                <p><strong>Beneficio:</strong> Esto reduce el riesgo de fraudes y asegura que las transacciones se mantengan dentro de un entorno controlado.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 5. Sistema de Reportes */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <Flag className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">5. Sistema de Reportes y Filtros</h2>
              <div className="space-y-4">
                <p><strong>Reportar contenido:</strong> Puedes reportar productos, perfiles o mensajes sospechosos directamente desde la plataforma.</p>
                <p><strong>Revisión rápida:</strong> Nuestro equipo de soporte revisa y toma medidas sobre los reportes en el menor tiempo posible.</p>
                <p><strong>Reglas claras:</strong> Prohibimos la venta de artículos ilegales o inapropiados, y aplicamos filtros automáticos para evitar publicaciones indebidas.</p>
                <p><strong>Beneficio:</strong> Estas herramientas ayudan a mantener un espacio seguro y libre de contenido problemático.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 6. Protección de Pagos */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <CreditCard className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">6. Protección de Pagos</h2>
              <div className="space-y-4">
                <p><strong>Pasarela de pago segura:</strong> Utilizamos sistemas de pago confiables con cifrado SSL para proteger tu información financiera.</p>
                <p><strong>Depósito en garantía (escrow):</strong> Retenemos el dinero del comprador hasta que confirme que recibió el producto en buen estado.</p>
                <p><strong>Notificaciones:</strong> Te informamos cada vez que se realiza un pago o transferencia en tu cuenta.</p>
                <p><strong>Beneficio:</strong> Esto protege tanto a compradores como a vendedores, reduciendo el riesgo de fraudes.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 7. Consejos de Seguridad */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <Lightbulb className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">7. Consejos de Seguridad para Usuarios</h2>
              <div className="space-y-4">
                <p><strong>Buenas prácticas:</strong> Recomendamos verificar los productos antes de comprarlos y realizar intercambios en lugares seguros, como zonas públicas dentro del campus.</p>
                <p><strong>Punto de encuentro sugerido:</strong> Para mayor seguridad, realiza las entregas en lugares concurridos de tu universidad.</p>
                <p><strong>Beneficio:</strong> Alentamos a nuestra comunidad a tomar precauciones adicionales para evitar riesgos innecesarios.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 8. Monitoreo */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <Eye className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">8. Monitoreo de Actividades Sospechosas</h2>
              <div className="space-y-4">
                <p><strong>Detección automática:</strong> Nuestros sistemas identifican comportamientos inusuales, como intentos de login fallidos o publicaciones masivas de productos.</p>
                <p><strong>Suspensiones automáticas:</strong> Bloqueamos temporalmente perfiles sospechosos hasta que sean revisados manualmente.</p>
                <p><strong>Beneficio:</strong> Esto nos permite actuar rápidamente para proteger a la comunidad ante posibles amenazas.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Contacto y Soporte */}
        <section className="bg-white rounded-lg shadow-md p-8">
          <div className="flex items-start">
            <Shield className="h-8 w-8 text-primary-700 mr-4 flex-shrink-0" />
            <div>
              <h2 className="text-xl font-bold mb-4">Contacto y Soporte</h2>
              <p>Si tienes alguna duda o necesitas ayuda, puedes contactarnos en <Link to="/support" className="text-primary-700 hover:underline">infouniswitch@gmail.com</Link>. Nuestro equipo de soporte está aquí para asistirte.</p>
            </div>
          </div>
        </section>

        <div className="text-center text-gray-600 mt-8">
          <p>En UniSwitch, trabajamos constantemente para mejorar la seguridad y confianza en nuestra plataforma. ¡Tu tranquilidad es nuestra prioridad!</p>
        </div>
      </div>
    </div>
  );
}