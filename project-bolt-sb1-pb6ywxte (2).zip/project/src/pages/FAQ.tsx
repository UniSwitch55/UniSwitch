import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

type FAQItem = {
  question: string;
  answer: string;
};

const faqs: FAQItem[] = [
  {
    question: "¿Qué es UniSwitch?",
    answer: "UniSwitch es un marketplace exclusivo para estudiantes, diseñado para que puedas comprar y vender objetos de manera segura con personas de tu misma universidad. Nuestra plataforma promueve la confianza al conectar a estudiantes verificados con correos universitarios."
  },
  {
    question: "¿Cómo me registro en UniSwitch?",
    answer: "El registro es sencillo. Solo necesitas un correo electrónico asociado a tu universidad (por ejemplo, @universidad.edu) para verificar tu identidad como estudiante."
  },
  {
    question: "¿Qué tipo de productos puedo vender o comprar?",
    answer: "En UniSwitch puedes encontrar y publicar una variedad de artículos, como libros de texto, ropa, tecnología, materiales de estudio y más. Los productos deben ser legales y cumplir con nuestras políticas de uso."
  },
  {
    question: "¿Cómo puedo filtrar los productos para ver solo los de mi universidad?",
    answer: "En la plataforma, puedes usar los filtros disponibles para mostrar únicamente los productos que están siendo vendidos por estudiantes de tu universidad. Esto facilita las transacciones locales y seguras."
  },
  {
    question: "¿Cómo sé que es seguro comprar o vender en UniSwitch?",
    answer: "En UniSwitch, solo los estudiantes con correos universitarios verificados pueden registrarse, lo que asegura que interactúes únicamente con personas de tu misma universidad. Además, puedes contactar directamente con el vendedor para conocer más detalles antes de realizar una compra."
  },
  {
    question: "¿Puedo contactar a otros estudiantes a través de UniSwitch?",
    answer: "Sí, puedes comunicarte directamente con otros estudiantes a través de nuestra plataforma para negociar precios, coordinar entregas o resolver dudas sobre los productos."
  },
  {
    question: "¿Qué hago si tengo un problema con una transacción?",
    answer: "Si tienes algún problema, te invitamos a ponerte en contacto con nuestro equipo de soporte enviando un correo a infouniswitch@gmail.com. Estamos aquí para ayudarte."
  },
  {
    question: "¿Qué ventajas ofrece UniSwitch frente a otros marketplaces?",
    answer: "UniSwitch es exclusivo para estudiantes, lo que garantiza mayor seguridad y confianza. Además, puedes comprar y vender de forma local con personas de tu misma edad y universidad, lo que facilita las transacciones y fomenta el sentido de comunidad."
  },
  {
    question: "¿Qué hago si tengo preguntas adicionales?",
    answer: "Si tienes dudas que no están resueltas aquí, no dudes en escribirnos a infouniswitch@gmail.com. Nuestro equipo estará encantado de ayudarte."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900">Preguntas Frecuentes</h1>
        <p className="mt-4 text-gray-600">
          Encuentra respuestas a las preguntas más comunes sobre UniSwitch
        </p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"
          >
            <button
              onClick={() => toggleQuestion(index)}
              className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50"
            >
              <span className="font-medium text-gray-900">{faq.question}</span>
              {openIndex === index ? (
                <ChevronUp className="h-5 w-5 text-gray-500" />
              ) : (
                <ChevronDown className="h-5 w-5 text-gray-500" />
              )}
            </button>
            {openIndex === index && (
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}