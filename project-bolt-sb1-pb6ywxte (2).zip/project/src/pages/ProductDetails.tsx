import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { MessageCircle, ShoppingCart, Star, Heart, Flag, Eye, MoreVertical, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';

type Product = {
  id: string;
  title: string;
  description: string;
  price: number;
  condition: string;
  category: string;
  image_url: string;
  image_urls: string[];
  seller_id: string;
  seller: {
    username: string;
    avatar_url: string;
  };
};

type Review = {
  id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer: {
    username: string;
    avatar_url: string;
  };
};

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [sellerProducts, setSellerProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [addingToCart, setAddingToCart] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [viewCount, setViewCount] = useState(0);
  const [saveCount, setSaveCount] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [allImages, setAllImages] = useState<string[]>([]);

  const fetchProduct = async () => {
    try {
      if (!id) return;

      const { data: product, error: productError } = await supabase
        .from('products')
        .select(`
          *,
          seller:profiles(username, avatar_url)
        `)
        .eq('id', id)
        .single();

      if (productError) throw productError;
      setProduct(product);

      // Fetch view count
      const { count: viewCount } = await supabase
        .from('product_views')
        .select('*', { count: 'exact' })
        .eq('product_id', id);

      setViewCount(viewCount || 0);

      // Fetch save count
      const { count: saveCount } = await supabase
        .from('saved_products')
        .select('*', { count: 'exact' })
        .eq('product_id', id);

      setSaveCount(saveCount || 0);

      // Check if current user has saved this product
      if (currentUser) {
        const { data: savedData } = await supabase
          .from('saved_products')
          .select('id')
          .eq('product_id', id)
          .eq('user_id', currentUser.id)
          .single();

        setIsSaved(!!savedData);
      }

      if (product?.seller_id) {
        const { data: sellerData, error: sellerError } = await supabase
          .from('products')
          .select(`
            *,
            seller:profiles(username, avatar_url)
          `)
          .eq('seller_id', product.seller_id)
          .neq('id', id)
          .eq('status', 'available')
          .limit(4);

        if (!sellerError && sellerData) {
          setSellerProducts(sellerData);
        }

        const { data: reviewsData, error: reviewsError } = await supabase
          .from('reviews')
          .select(`
            *,
            reviewer:profiles!reviews_reviewer_id_fkey(username, avatar_url)
          `)
          .eq('seller_id', product.seller_id)
          .order('created_at', { ascending: false })
          .limit(5);

        if (!reviewsError && reviewsData) {
          setReviews(reviewsData);
        }
      }
    } catch (error: any) {
      console.error('Error fetching product:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
    if (id) {
      fetchProduct();
    }
  }, [id]);

  useEffect(() => {
    if (product) {
      // Combine all available images into a single array
      const images = product.image_urls || [];
      if (product.image_url && !images.includes(product.image_url)) {
        images.unshift(product.image_url);
      }
      setAllImages(images);
    }
  }, [product]);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    setCurrentUser(user);
  };

  const handleDelete = async () => {
    if (!confirm('¿Estás seguro de que quieres eliminar este producto?')) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;
      navigate('/profile');
    } catch (error) {
      console.error('Error deleting product:', error);
      setError('Error al eliminar el producto');
    }
  };

  const handleAddToCart = async () => {
    if (!currentUser) {
      navigate('/auth');
      return;
    }

    setAddingToCart(true);
    try {
      const { error } = await supabase
        .from('cart_items')
        .upsert({
          user_id: currentUser.id,
          product_id: product?.id,
          quantity: 1
        }, {
          onConflict: 'user_id,product_id'
        });

      if (error) throw error;
      navigate('/cart');
    } catch (error: any) {
      console.error('Error adding to cart:', error);
      setError('Error al añadir al carrito');
    } finally {
      setAddingToCart(false);
    }
  };

  const handleBuyNow = () => {
    if (!currentUser) {
      navigate('/auth');
      return;
    }
    navigate(`/checkout?product=${product?.id}`);
  };

  const handleContact = async () => {
    if (!currentUser) {
      navigate('/auth');
      return;
    }

    if (!product) {
      setError('Error al cargar el producto');
      return;
    }

    if (currentUser.id === product.seller_id) {
      setError('No puedes enviarte mensajes a ti mismo');
      return;
    }

    navigate(`/messages?seller=${product.seller_id}&product=${product.id}`);
  };

  const handleReport = async () => {
    if (!currentUser) {
      navigate('/auth');
      return;
    }
    setShowReportModal(true);
  };

  const submitReport = async () => {
    if (!reportReason.trim() || !currentUser || !product) return;

    try {
      const { error } = await supabase
        .from('reports')
        .insert({
          user_id: currentUser.id,
          product_id: product.id,
          reason: reportReason
        });

      if (error) throw error;
      setShowReportModal(false);
      setReportReason('');
      alert('Reporte enviado correctamente');
    } catch (error) {
      console.error('Error submitting report:', error);
    }
  };

  const toggleSave = async () => {
    if (!currentUser) {
      navigate('/auth');
      return;
    }

    try {
      if (isSaved) {
        await supabase
          .from('saved_products')
          .delete()
          .eq('product_id', id)
          .eq('user_id', currentUser.id);
        setSaveCount(prev => prev - 1);
      } else {
        await supabase
          .from('saved_products')
          .insert({
            product_id: id,
            user_id: currentUser.id
          });
        setSaveCount(prev => prev + 1);
      }
      setIsSaved(!isSaved);
    } catch (error) {
      console.error('Error toggling save:', error);
    }
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % allImages.length);
  };

  const previousImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-700"></div>
    </div>;
  }

  if (!product) {
    return <div className="text-center py-8">
      <p className="text-red-600">Producto no encontrado</p>
    </div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="relative h-96">
            <img
              src={allImages[currentImageIndex] || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
              alt={product.title}
              className="w-full h-full object-cover"
            />
            {allImages.length > 1 && (
              <>
                <button
                  onClick={previousImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-white rounded-full shadow-md hover:bg-gray-100"
                >
                  <ChevronLeft className="h-6 w-6" />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white rounded-full shadow-md hover:bg-gray-100"
                >
                  <ChevronRight className="h-6 w-6" />
                </button>
              </>
            )}
          </div>
          {allImages.length > 1 && (
            <div className="flex justify-center gap-2 p-4">
              {allImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-2 h-2 rounded-full ${
                    currentImageIndex === index ? 'bg-primary-700' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-start mb-4">
              <h1 className="text-3xl font-bold text-gray-900">{product.title}</h1>
              <div className="relative">
                <button
                  onClick={() => setShowMenu(!showMenu)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <MoreVertical className="h-6 w-6 text-gray-500" />
                </button>
                {showMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg z-10">
                    {currentUser?.id === product.seller_id ? (
                      <>
                        <button
                          onClick={() => navigate(`/products/edit/${product.id}`)}
                          className="w-full px-4 py-2 text-left flex items-center hover:bg-gray-100"
                        >
                          <Pencil className="h-4 w-4 mr-2" />
                          Editar producto
                        </button>
                        <button
                          onClick={handleDelete}
                          className="w-full px-4 py-2 text-left flex items-center text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Eliminar producto
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={handleReport}
                        className="w-full px-4 py-2 text-left flex items-center hover:bg-gray-100"
                      >
                        <Flag className="h-4 w-4 mr-2" />
                        Reportar
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center text-gray-500">
                <Eye className="h-5 w-5 mr-1" />
                <span>{viewCount} vistas</span>
              </div>
              <button
                onClick={toggleSave}
                className={`flex items-center ${
                  isSaved ? 'text-red-500' : 'text-gray-500'
                }`}
              >
                <Heart
                  className={`h-5 w-5 mr-1 ${
                    isSaved ? 'fill-current' : ''
                  }`}
                />
                <span>{saveCount}</span>
              </button>
            </div>

            <p className="text-2xl font-bold text-primary-700 mb-4">
              €{product.price.toFixed(2)}
            </p>

            <div className="flex items-center space-x-4 mb-6">
              <span className="px-3 py-1 bg-gray-100 rounded-full text-gray-800">
                {product.condition}
              </span>
              <span className="px-3 py-1 bg-gray-100 rounded-full text-gray-800">
                {product.category}
              </span>
            </div>

            <p className="text-gray-600 mb-6">{product.description}</p>

            {/* Seller Info */}
            <div className="border-t pt-6">
              <div className="flex items-center space-x-4">
                <img
                  src={product.seller.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'}
                  alt={product.seller.username}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <h3 className="font-medium text-gray-900">
                    Vendido por {product.seller.username}
                  </h3>
                  <div className="flex items-center mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="h-4 w-4 text-yellow-400"
                        fill="currentColor"
                      />
                    ))}
                    <span className="ml-2 text-sm text-gray-500">
                      ({reviews.length} valoraciones)
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4 mt-6">
              <button
                onClick={handleBuyNow}
                className="flex-1 px-6 py-3 bg-primary-700 text-white rounded-lg hover:bg-primary-800"
              >
                Comprar ahora
              </button>
              <button
                onClick={handleAddToCart}
                disabled={addingToCart}
                className="flex-1 px-6 py-3 border border-primary-700 text-primary-700 rounded-lg hover:bg-primary-50"
              >
                {addingToCart ? 'Añadiendo...' : 'Añadir al carrito'}
              </button>
              <button
                onClick={handleContact}
                className="px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                <MessageCircle className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Other Products */}
      {sellerProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Más productos de {product.seller.username}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {sellerProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer"
                onClick={() => navigate(`/products/${product.id}`)}
              >
                <img
                  src={product.image_url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e'}
                  alt={product.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{product.title}</h3>
                  <p className="text-xl font-bold text-primary-700">
                    €{product.price.toFixed(2)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Reportar producto
            </h3>
            <textarea
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              placeholder="Describe el motivo del reporte..."
              rows={4}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 mb-4"
            />
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowReportModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                onClick={submitReport}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Enviar reporte
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}