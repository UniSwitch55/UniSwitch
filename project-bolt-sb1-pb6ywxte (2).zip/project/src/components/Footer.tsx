import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          {/* Logo and Copyright */}
          <div className="md:col-span-1">
            <div className="flex flex-col items-start">
              <div className="text-primary-700 font-bold text-2xl mb-4">
                UniSwitch
              </div>
              <p className="text-sm text-gray-500">
                © {new Date().getFullYear()} UniSwitch.<br />
                Todos los derechos reservados.
              </p>
            </div>
          </div>

          {/* Quiénes Somos */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Quiénes Somos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-600 hover:text-secondary-400">
                  Sobre nosotros
                </Link>
              </li>
              <li>
                <Link to="/team" className="text-gray-600 hover:text-secondary-400">
                  Nuestro equipo
                </Link>
              </li>
              <li>
                <Link to="/careers" className="text-gray-600 hover:text-secondary-400">
                  Trabaja con nosotros
                </Link>
              </li>
            </ul>
          </div>

          {/* Contáctanos */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Contáctanos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/support" className="text-gray-600 hover:text-secondary-400">
                  Soporte
                </Link>
              </li>
              <li>
                <a href="mailto:info@uniswitch.com" className="text-gray-600 hover:text-secondary-400">
                  info@uniswitch.com
                </a>
              </li>
            </ul>
          </div>

          {/* Cómo Funciona */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Cómo Funciona</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/guide" className="text-gray-600 hover:text-secondary-400">
                  Guía de uso
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-600 hover:text-secondary-400">
                  Preguntas frecuentes
                </Link>
              </li>
              <li>
                <Link to="/security" className="text-gray-600 hover:text-secondary-400">
                  Seguridad
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/terms" className="text-gray-600 hover:text-secondary-400">
                  Términos y condiciones
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-600 hover:text-secondary-400">
                  Política de privacidad
                </Link>
              </li>
              <li>
                <Link to="/cookies" className="text-gray-600 hover:text-secondary-400">
                  Política de cookies
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Media and Download */}
        <div className="mt-8 pt-8 border-t flex flex-col md:flex-row justify-between items-center">
          {/* Social Media Icons */}
          <div className="flex space-x-6 mb-4 md:mb-0">
            <a
              href="https://instagram.com/uniswitch_?igsh=cjB4NXA2OW52bW5y"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-secondary-400 transition-colors"
            >
              <Instagram className="h-6 w-6" />
            </a>
            <a
              href="https://www.tiktok.com/@uniswitch_?_t=ZN-8t5E51pzprC&_r=1"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-secondary-400 transition-colors"
            >
              <svg
                className="h-6 w-6"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
              </svg>
            </a>
            <a
              href="https://x.com/UniSwitch_?t=PXkxVMZCbQxs0fmnNaYVLw&s=09"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-secondary-400 transition-colors"
            >
              <Twitter className="h-6 w-6" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}