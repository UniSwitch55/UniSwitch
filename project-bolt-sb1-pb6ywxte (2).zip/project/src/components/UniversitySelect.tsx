import React, { useState, useEffect, useRef } from 'react';
import { Search } from 'lucide-react';
import { universities } from '../lib/universities';

interface UniversitySelectProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

export default function UniversitySelect({ value, onChange, className = '' }: UniversitySelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const filteredUniversities = universities.filter(uni =>
    uni.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedUniversity = universities.find(uni => uni.id === value);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-3 py-2 text-left border rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
      >
        {selectedUniversity ? selectedUniversity.name : 'Selecciona una universidad'}
      </button>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border rounded-lg shadow-lg">
          <div className="p-2 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar universidad..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 border rounded-md focus:ring-2 focus:ring-primary-500"
              />
            </div>
          </div>
          <div className="max-h-60 overflow-y-auto">
            {filteredUniversities.map((uni) => (
              <button
                key={uni.id}
                onClick={() => {
                  onChange(uni.id);
                  setIsOpen(false);
                  setSearchTerm('');
                }}
                className={`w-full px-3 py-2 text-left hover:bg-gray-100 ${
                  value === uni.id ? 'bg-primary-50 text-primary-700' : ''
                }`}
              >
                {uni.name}
              </button>
            ))}
            {filteredUniversities.length === 0 && (
              <div className="px-3 py-2 text-gray-500 text-center">
                No se encontraron resultados
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}