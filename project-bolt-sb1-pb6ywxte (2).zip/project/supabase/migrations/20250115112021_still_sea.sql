/*
  # Update messages and product views

  1. Changes
    - Add read_at and image_url columns to messages table
    - Create product_views table for tracking product view statistics
  
  2. Security
    - Enable RLS on product_views table
    - Add policies for viewing and creating product views
*/

-- Update messages table to ensure all required columns exist
ALTER TABLE messages 
ADD COLUMN IF NOT EXISTS read_at timestamptz,
ADD COLUMN IF NOT EXISTS image_url text;

-- Create product_views table if it doesn't exist
CREATE TABLE IF NOT EXISTS product_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  viewer_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(product_id, viewer_id)
);

-- Enable RLS
ALTER TABLE product_views ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Product owners can view their product stats" ON product_views;
    DROP POLICY IF EXISTS "Users can create views" ON product_views;
EXCEPTION
    WHEN undefined_object THEN
        NULL;
END $$;

-- Create new policies
CREATE POLICY "Product owners can view their product stats"
  ON product_views FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_views.product_id
      AND products.seller_id = auth.uid()
    )
  );

CREATE POLICY "Users can create views"
  ON product_views FOR INSERT
  WITH CHECK (auth.uid() = viewer_id);