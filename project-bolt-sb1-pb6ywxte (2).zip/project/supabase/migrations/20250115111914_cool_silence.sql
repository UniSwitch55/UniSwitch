/*
  # Add saved products table and update messages

  1. Tables
    - Create saved_products if not exists
    - Update messages table with new columns
  
  2. Security
    - Enable RLS
    - Add policies for saved_products
*/

-- Create saved_products table if it doesn't exist
CREATE TABLE IF NOT EXISTS saved_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

-- Enable RLS
ALTER TABLE saved_products ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can view their saved products" ON saved_products;
    DROP POLICY IF EXISTS "Users can save products" ON saved_products;
    DROP POLICY IF EXISTS "Users can unsave products" ON saved_products;
EXCEPTION
    WHEN undefined_object THEN
        NULL;
END $$;

-- Create new policies
CREATE POLICY "Users can view their saved products"
  ON saved_products FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can save products"
  ON saved_products FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unsave products"
  ON saved_products FOR DELETE
  USING (auth.uid() = user_id);

-- Update messages table to ensure all required columns exist
ALTER TABLE messages 
ADD COLUMN IF NOT EXISTS read_at timestamptz,
ADD COLUMN IF NOT EXISTS image_url text;