/*
  # Add product_id to search_history table

  1. Changes
    - Add product_id column to search_history table
    - Add foreign key constraint to products table
*/

ALTER TABLE search_history
ADD COLUMN IF NOT EXISTS product_id uuid REFERENCES products(id) ON DELETE CASCADE;