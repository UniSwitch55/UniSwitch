-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can view their saved products" ON saved_products;
    DROP POLICY IF EXISTS "Users can save products" ON saved_products;
    DROP POLICY IF EXISTS "Users can unsave products" ON saved_products;
    DROP POLICY IF EXISTS "Users can view their reports" ON reports;
    DROP POLICY IF EXISTS "Users can create reports" ON reports;
EXCEPTION
    WHEN undefined_object THEN
        NULL;
END $$;

-- Create new policies
CREATE POLICY "Users can view their saved products"
  ON saved_products FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can save products"
  ON saved_products FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unsave products"
  ON saved_products FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view their reports"
  ON reports FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create reports"
  ON reports FOR INSERT
  WITH CHECK (auth.uid() = user_id);