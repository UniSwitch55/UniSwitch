/*
  # Add image_urls column to products table

  1. Changes
    - Add image_urls column to products table to store multiple image URLs
*/

ALTER TABLE products
ADD COLUMN IF NOT EXISTS image_urls text[];