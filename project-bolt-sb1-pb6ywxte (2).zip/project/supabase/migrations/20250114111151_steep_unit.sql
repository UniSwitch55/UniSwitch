/*
  # Add search history and university field

  1. Changes
    - Add `university` column to profiles table
    - Create search_history table for tracking user searches
    - Fix reviews query by adding proper foreign key references

  2. Security
    - Enable RLS on search_history table
    - Add policies for search history management
*/

-- Add university column to profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS university text;

-- Create search_history table
CREATE TABLE IF NOT EXISTS search_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  search_query text NOT NULL,
  filters jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE search_history ENABLE ROW LEVEL SECURITY;

-- Search history policies
CREATE POLICY "Users can view own search history"
  ON search_history FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create search history"
  ON search_history FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Fix reviews query by updating the foreign key references
CREATE POLICY "Users can view reviews"
  ON reviews FOR SELECT
  USING (true);