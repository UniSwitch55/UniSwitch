/*
  # Add payment information table
  
  1. New Tables
    - payment_info table for storing user payment methods
    
  2. Security
    - Enable RLS
    - Add policies for secure access
*/

-- Create payment_info table
CREATE TABLE IF NOT EXISTS payment_info (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  paypal_email text,
  bizum_phone text,
  card_last_four text,
  card_brand text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE payment_info ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own payment info"
  ON payment_info FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own payment info"
  ON payment_info FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own payment info"
  ON payment_info FOR UPDATE
  USING (auth.uid() = user_id);